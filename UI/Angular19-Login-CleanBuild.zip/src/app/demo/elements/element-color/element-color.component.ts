// angular import
import { Component } from '@angular/core';

@Component({
  selector: 'app-element-color',
  imports: [],
  templateUrl: './element-color.component.html',
  styleUrls: ['./element-color.component.scss']
})
export default class ElementColorComponent {}
