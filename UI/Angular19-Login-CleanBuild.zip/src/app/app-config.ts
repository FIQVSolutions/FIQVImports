export class BerryConfig {
  static isCollapse_menu = false;
  static font_family = 'Roboto'; // Roboto, poppins, inter
}
